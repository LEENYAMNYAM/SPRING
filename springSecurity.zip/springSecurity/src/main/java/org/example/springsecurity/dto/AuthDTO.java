package org.example.springsecurity.dto;

import lombok.Data;

@Data
public class AuthDTO {
    private String userid;
    private String auth;

}
